const express = require('express');
const {faker} = require('@faker-js/faker');
const app = express();
const port = 8000;

const createUser = () => ({
    _id : faker.database.mongodbObjectId(),
    firstName : faker.name.firstName(),
    lastName : faker.name.lastName(),
    email : faker.internet.email(),
    phoneNumber : faker.phone.number(),
    password : faker.internet.password()
})

const createCompany = () => ({
    _id : faker.database.mongodbObjectId(),
    name : faker.company.name(),
    address: {
        country : faker.address.country(),
        state : faker.address.state(),
        zipCode: faker.address.zipCode(),
        city : faker.address.cityName(),
        street : faker.address.street()
    }
})

app.get("/api/users/new", (req, res) => {
    res.json(createUser());
})

app.get("/api/companies/new", (req, res) => {
    res.json(createCompany());
})

app.get("/api/user/company", (req, res) => {
    const newUser = createUser();
    const newCompany = createCompany();
    const addTogether = {user : newUser, company : newCompany};
    res.json(addTogether);
})

app.listen(port, () => console.log(`Listening on port: ${port}`));
