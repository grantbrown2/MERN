import React, { useState, useEffect } from 'react'
import '../Styles.css';

const TodoForm = () => {
    // const [list, setList] = useState([]); ORIGINAL HOOK BEFORE SENSEI BONUS 
    const [list, setList] = useState(()=> { // Modified hook to check if a list already exists in local storage, if it does then it will apply it.
        const storedList = localStorage.getItem('todoList'); // retrieves "todoList" from localStorage with the .getItem
        return storedList ? JSON.parse(storedList) : []; // ? if the list exists in the local storage then it will apply the list, : if not it will default to an empty array
    });
    const [newItem, setNewItem] = useState('');

    const addItem = (e) => {
        e.preventDefault();
        setList([...list, {name:newItem, isComplete : false}]);
        setNewItem('');
    }

    const markComplete = (id) => { // this function is called onChange on the checkbox form
        const newList = [...list]; // creates a copy of our list
        newList[id].isComplete = !newList[id].isComplete; // we access the isCompleted and toggles its value using !
        setList(newList); // updates our list by calling setList function with updated newList
    }

    const removeItem = (id) => { // when the button is pressed onClick called this function with the id associated with the item
        const newList = [...list]; // creates a copy of our list
        newList.splice(id, 1); // splice removes one item from our list on the id specified
        setList(newList); // updates our list by calling setList function with updated newList
    }

    //SENSEI BONUS
    // CHATGPT EXPLANATION: This code sets up a side effect that runs every time the list changes. It updates the 'todoList' item in the local storage with the current value of the list.
    useEffect(() => {
        localStorage.setItem('todoList', JSON.stringify(list));//*SENSEI BONUS CHATGPT: This code converts the list array to a JSON string
                                                                // and stores it in the 'todoList' key in the local storage.
    }, [list]); // second argument is responsible for useEffect being called every time 'list' is modified
    // previously I was adding localStorage.setItem('todoList', JSON.stringify(list)); to each function that I wanted to update localStorage, instead useEffect is called every time I update
    // "list" so I was able to refactor and reduce my code
    
        


    return (
        <div>
            <h1>Todo List</h1>
            <div className="container">
                <form onSubmit={addItem}>
                    <input className='item-name' placeholder='Enter Item Here' type="text" value={newItem} onChange={(e) => setNewItem(e.target.value)}/>
                    <input type="submit" value="Add" className='item-submit'/>
                </form>
            </div>
            <div className="container">
            <ul>
                {list.map((item, id) => (
                    <li key={id}>
                        <span style={{textDecoration: item.isComplete ? 'line-through' : 'none'}}>{item.name}</span>
                        <input className='check' type="checkbox" checked={item.isComplete} onChange={() => markComplete(id)}/>
                        <button onClick={() => removeItem(id)}>Remove</button>
                    </li>
                ))}
            </ul>
            </div>
        </div>
    )
}

export default TodoForm